package com.percentageonly.timer;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private ProgressRingView ring;
    private TextView status;
    private Button startButton, durationButton;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private long durationMs = 2 * 60 * 60 * 1000L;
    private long startAt = 0L;
    private long elapsedBeforePause = 0L;
    private boolean running = false;

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (!running) return;
            long elapsed = elapsedBeforePause + (android.os.SystemClock.elapsedRealtime() - startAt);
            float progress = Math.min(1f, (float) elapsed / (float) durationMs);
            int percent = progress >= 1f ? 100 : Math.max(1, (int)(progress * 100f));
            ring.setProgress(progress, percent);
            if (progress >= 1f) {
                running = false;
                elapsedBeforePause = durationMs;
                startButton.setText("START AGAIN");
                status.setText("Interval complete");
                return;
            }
            handler.postDelayed(this, 250);
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ring = findViewById(R.id.progressRing);
        status = findViewById(R.id.statusText);
        startButton = findViewById(R.id.startButton);
        Button resetButton = findViewById(R.id.resetButton);
        durationButton = findViewById(R.id.durationButton);

        startButton.setOnClickListener(v -> {
            if (running) {
                running = false;
                elapsedBeforePause += android.os.SystemClock.elapsedRealtime() - startAt;
                handler.removeCallbacks(ticker);
                startButton.setText("RESUME");
                status.setText("Paused");
            } else {
                if (elapsedBeforePause >= durationMs) elapsedBeforePause = 0L;
                startAt = android.os.SystemClock.elapsedRealtime();
                running = true;
                startButton.setText("PAUSE");
                status.setText("Progress only");
                handler.removeCallbacks(ticker);
                handler.post(ticker);
            }
        });

        resetButton.setOnClickListener(v -> resetTimer());
        durationButton.setOnClickListener(v -> showDurationDialog());
        ring.setProgress(0f, 1);
    }

    private void resetTimer() {
        running = false;
        handler.removeCallbacks(ticker);
        elapsedBeforePause = 0L;
        startAt = 0L;
        ring.setProgress(0f, 1);
        startButton.setText("START");
        status.setText("Ready when you are");
    }

    private void showDurationDialog() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setPadding(24, 8, 24, 8);

        EditText hours = new EditText(this);
        hours.setHint("Hours");
        hours.setInputType(2);
        hours.setSingleLine(true);
        hours.setText(String.valueOf(durationMs / 3600000L));

        EditText minutes = new EditText(this);
        minutes.setHint("Minutes");
        minutes.setInputType(2);
        minutes.setSingleLine(true);
        minutes.setText(String.valueOf((durationMs / 60000L) % 60L));

        layout.addView(hours, new LinearLayout.LayoutParams(0, -2, 1));
        layout.addView(minutes, new LinearLayout.LayoutParams(0, -2, 1));

        new AlertDialog.Builder(this)
            .setTitle("Set interval")
            .setMessage("Choose the duration. The screen will show percentage only.")
            .setView(layout)
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("SAVE", (dialog, which) -> {
                try {
                    int h = hours.getText().toString().trim().isEmpty() ? 0 : Integer.parseInt(hours.getText().toString().trim());
                    int m = minutes.getText().toString().trim().isEmpty() ? 0 : Integer.parseInt(minutes.getText().toString().trim());
                    if (h < 0 || m < 0 || (h == 0 && m == 0) || m > 59 || h > 99) {
                        Toast.makeText(this, "Enter a valid duration", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    durationMs = (h * 60L + m) * 60000L;
                    durationButton.setText("INTERVAL: " + (h > 0 ? h + " HOUR" + (h == 1 ? "" : "S") : "") +
                        (h > 0 && m > 0 ? " " : "") + (m > 0 ? m + " MIN" : ""));
                    resetTimer();
                } catch (NumberFormatException e) {
                    Toast.makeText(this, "Enter a valid duration", Toast.LENGTH_SHORT).show();
                }
            }).show();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacks(ticker);
        super.onDestroy();
    }
}
