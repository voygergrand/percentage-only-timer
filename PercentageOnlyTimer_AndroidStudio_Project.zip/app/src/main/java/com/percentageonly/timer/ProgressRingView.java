package com.percentageonly.timer;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

public class ProgressRingView extends View {
    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint progressPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint numberPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hintPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float progress = 0f;
    private int percent = 1;

    public ProgressRingView(Context context, AttributeSet attrs) {
        super(context, attrs);
        track.setStyle(Paint.Style.STROKE);
        track.setStrokeWidth(10f);
        track.setColor(0xFF253247);
        track.setStrokeCap(Paint.Cap.ROUND);
        progressPaint.setStyle(Paint.Style.STROKE);
        progressPaint.setStrokeWidth(10f);
        progressPaint.setColor(0xFF36D399);
        progressPaint.setStrokeCap(Paint.Cap.ROUND);
        numberPaint.setColor(0xFF36D399);
        numberPaint.setTextAlign(Paint.Align.CENTER);
        numberPaint.setTypeface(android.graphics.Typeface.create("sans-serif-medium", 0));
        hintPaint.setColor(0xFFA8B4C8);
        hintPaint.setTextAlign(Paint.Align.CENTER);
        hintPaint.setTextSize(13f);
    }

    public void setProgress(float value, int shownPercent) {
        progress = Math.max(0f, Math.min(1f, value));
        percent = shownPercent;
        invalidate();
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float cx = getWidth() / 2f, cy = getHeight() / 2f;
        float radius = Math.min(getWidth(), getHeight()) * 0.405f;
        RectF oval = new RectF(cx - radius, cy - radius, cx + radius, cy + radius);
        canvas.drawArc(oval, -90f, 360f, false, track);
        if (progress > 0f) canvas.drawArc(oval, -90f, 360f * progress, false, progressPaint);
        numberPaint.setTextSize(Math.min(getWidth(), getHeight()) * 0.245f);
        Paint.FontMetrics fm = numberPaint.getFontMetrics();
        float baseline = cy - (fm.ascent + fm.descent) / 2f - 7f;
        canvas.drawText(percent + "%", cx, baseline, numberPaint);
        canvas.drawText("PROGRESS", cx, cy + Math.min(getWidth(), getHeight()) * 0.19f, hintPaint);
    }
}
